from .toml_parser import *

__doc__ = toml_parser.__doc__
if hasattr(toml_parser, "__all__"):
    __all__ = toml_parser.__all__